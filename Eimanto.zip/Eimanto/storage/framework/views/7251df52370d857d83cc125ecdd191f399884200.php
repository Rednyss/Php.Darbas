<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="/add/event" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Pavadinimas</label>
            <input type="text" id="title" name="title" class="form-control">
        </div>
        <div class="form-group">
            <label for="description">Aprašymas</label>
            <textarea name="description" id="description" cols="30" rows="3" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label for="date">Pradinė data</label>
            <input type="date" id="date" name="start_date" class="form-control">
        </div>
        <div class="form-group">
            <label for="image">Antraštė</label>
            <input type="file" id="image" name="image" class="form-control">
        </div>
        <div class="form-group">
            <button class="btn btn-primary" type="submit">Add</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eimanto darbas\resources\views/events/addEvent.blade.php ENDPATH**/ ?>