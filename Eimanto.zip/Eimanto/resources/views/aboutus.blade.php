@extends('layouts.app')

@section('content')

    <div class="container">
        <h2 class="h1-responsive font-weight-bold text-center my-4">Apie mus</h2>
        <p class="text-center w-responsive mx-auto mb-5 h5".>Sveiki Atvyke i mano svetaine</p>


    </div>
    <footer class="py-3 my-4 fixed-bottom">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3"></ul>
    <p class="text-center text-muted">©KITM2022</p>
  </footer>

@endsection
